const {createApp} = Vue

createApp({
    data() {
        return {
            display: '0',
            numeroAtual: null,
            numeroAnterior: null,
            operador: null,
            lidarOperador: '',
            lidarDecimal: '',
            lidarIgual: '',
            lidarClear: '0',
            lidarNumero: ''
        }
    },

    methods: {
        lidarBotao(lidarBotao){
            switch (lidarBotao){
                case "*":
                case "-":
                case "+":
                case "/":
                    this.lidarOperador(lidarBotao)
                    break
                case ".":
                    this.lidarDecimal(lidarBotao)
                    break
                case "=":
                    this.lidarIgual(lidarBotao)
                    break
                case "AC":
                    this.lidarClear(lidarBotao)
                    break
                default:
                    this.lidarNumero(lidarBotao)
            }
        },

        lidarOperador(){
            this.operador = this.operador;
            //'parseFloat()' = converte uma string em número decimal
            this.numeroAnterior = parseFloat(this.numeroAtual);
            this.numeroAtual = null;
        },

        lidarIgual(){
            if (this.operador && this.numeroAtual !== null && this.numeroAnterior !== null){
                switch (this.operador){
                    case "*":
                        this.numeroAtual = this.numeroAnterior *parseFloat(this.numeroAtual);
                        break;
                    case "-":
                        this.numeroAtual = this.numeroAnterior - parseFloat(this.numeroAtual);
                        break;
                    case "+":
                        this.numeroAtual = this.numeroAnterior + parseFloat(this.numeroAtual);
                        break;
                    case "/":
                        this.numeroAtual = this.numeroAnterior / parseFloat(this.numeroAtual);
                        break;
                }
                this.operador = null;
                this.numeroAnterior = null;
            }
        },

        lidarDecimal(){
            //'includes' = verifica se uma string contem outra
            if(!this.numeroAtual.includes('.')){
                this.numeroAtual += '.'
            }
        },

        lidarClear(){
            this.display = '0';
            this.numeroAtual = null;
            this.numeroAnterior = null;
            this.operador = null;
        },

        lidarNumero(numero){
            if(this.numeroAtual === null){
                this.numeroAtual = numero;
            } else {
                this.numeroAtual += numero;
            }
        }
    }
}).mount('#app')